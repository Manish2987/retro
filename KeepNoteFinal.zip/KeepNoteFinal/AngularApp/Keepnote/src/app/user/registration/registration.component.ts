import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/shared/user.service';
import { NgForm } from '@angular/forms';
import { AuthenticationService } from 'src/app/shared/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { Authentication } from 'src/app/shared/authentication.model';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent{

  constructor(private _userService: UserService,private _authenticationService: AuthenticationService
    ,private toast: ToastrService) { }
  authenticationData: Authentication = { UserId:'',Password:''};
  ngOnInit() {
    this.resetForm();
    localStorage.removeItem('token');
  }

  resetForm(userRegistrationForm? : NgForm)
  {
    if(userRegistrationForm !=null)
      userRegistrationForm.resetForm();
    this._userService.userFormData = {
      UserId:'',
      Name:'',
      Contact:'',      
      AddedDate:null
    }

    this._authenticationService.authenticationFormData={
      UserId:'',
      Password:''
    }
  }
  onSubmit(userRegistrationForm:NgForm)
  {
    debugger;
    this.authenticationData.UserId = userRegistrationForm.value.UserId;
    this.authenticationData.Password = userRegistrationForm.value.Password;
    this._authenticationService.postUserAuthenticationDetails(this.authenticationData)
    .subscribe(res => {
      debugger;
     this.insertUserDetails(userRegistrationForm);     
    },
    err =>{     
      debugger;  
      this.toast.error(err.error,"Registration failed");
      console.log(err);
    });
  }
  
  insertUserDetails(userRegistrationForm:NgForm)
  {
    this._userService.postUserDetails(userRegistrationForm.value)
    .subscribe(res => {
      this.toast.success("User registered successfully","User Registration");
      this.resetForm(userRegistrationForm);     
    },
    err =>{       
      this.toast.error(err.error,"Registration failed");
      console.log(err);
    });
  }
}
