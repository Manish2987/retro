import { Component, OnInit } from '@angular/core';
import { Authentication } from 'src/app/shared/authentication.model';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticationService } from 'src/app/shared/authentication.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router,private _authenticationService: AuthenticationService,
    private toast: ToastrService) { }
  authenticationFormData: Authentication = {UserId:'',Password:''}
  ngOnInit() {   
    debugger;
    if(localStorage.getItem('token') === null)
    {
      debugger;
      this.router.navigateByUrl('user/login');
    }
    else
    {
      debugger;
      this.router.navigateByUrl('Dashboard');
    }
  }
  
  ValidateUser(authenticationForm:NgForm)
  {
    debugger;
    this._authenticationService.postVerifyUserAuthenticationDetails(authenticationForm.value)
    
    .subscribe((res:any) => {
      debugger;
      localStorage.setItem('token',res.token);     
      this.router.navigateByUrl('Dashboard/UserProfile');
    },
    err => {
      debugger;
      if(err.status == 400)
        this.toast.error('Wrong User name/password','Authentication Failed');
    }    
    );
  }
}
