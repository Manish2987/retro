import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/shared/user.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  constructor(private _userService: UserService,private toast: ToastrService) { }  
  ngOnInit() {    
    debugger;
    this.loadUserDetails(); 
  }

  loadUserDetails()
  {    
    this._userService.getUserDetails().subscribe((res:any) => {      
      this._userService.userFormData = res;
    },
    err => {
      this.toast.error(err.error);
    });    
  }

  onSubmit(userForm : NgForm)
  {
    this.updateCategory(userForm);    
  }

  updateCategory(userForm : NgForm){
    this._userService.updateUserDetails(userForm.value).subscribe(res => {
      this.toast.info('User data updated successfully','Update User');      
    });
  }

}
