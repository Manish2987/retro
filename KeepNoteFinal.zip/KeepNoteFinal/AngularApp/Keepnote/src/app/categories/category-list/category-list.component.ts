import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/shared/category.service';
import { Category } from 'src/app/shared/category.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {

  constructor(private categoryService: CategoryService,private toast: ToastrService) { }
    
  ngOnInit() {
    debugger;
    this.getCategory();
  }
  populateForm(category: Category)
  {
    this.categoryService.categoryFormData = Object.assign({},category);
    this.categoryService.buttonText = "Update";
    this.categoryService.isUpdate=true;
  }

  getCategory(){
    this.categoryService.refreshList();    
  }

  onDelete(categoryId: number)
  {
    if(confirm('You want to delete category?'))
    {
    this.categoryService.deleteCategory(categoryId).subscribe(res=>{
      this.toast.warning('Deleted successfully','Delete Category');
      this.categoryService.refreshList();
    });
  }
  }
}
