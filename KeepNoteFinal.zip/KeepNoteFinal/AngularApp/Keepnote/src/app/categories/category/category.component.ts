import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/shared/category.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/shared/user.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  
  constructor(private _categoryService: CategoryService,private userService: UserService,
    private toast: ToastrService) { }
  
  ngOnInit() {
    this.resetForm();    
  }

  resetForm(categoryForm? : NgForm)
  {
    if(categoryForm !=null)
      categoryForm.resetForm();
    this._categoryService.categoryFormData = {
      Id:null,
      Name:'',
      Description:'',
      CreatedBy:this.userService.userFormData.UserId,
      CreationDate:null
    }
    this._categoryService.buttonText = "Create";
    this._categoryService.isUpdate = false;
    this._categoryService.refreshList();
  }

  onSubmit(categoryForm : NgForm)
  {
    if(categoryForm.value.Id == null)
      this.saveCategory(categoryForm);
    else
      this.updateCategory(categoryForm);    
  }
  saveCategory(categoryForm : NgForm)
  { 
    categoryForm.value.Id = 0;
    this._categoryService.postCategory(categoryForm.value).subscribe(res => {
      this.toast.success("Category added successfully","Create Category");
      this.resetForm(categoryForm);
      this._categoryService.refreshList();
    },
    err =>{      
      console.log(err);
      this.toast.error("Category already exists.","Create Category");
    });
  }

  updateCategory(categoryForm : NgForm){
    this._categoryService.putCategory(categoryForm.value).subscribe(res => {
      this.toast.info('Category data is updated successfully','Update Category');
      this.resetForm(categoryForm);      
    });
  }

}
