import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoriesComponent } from './categories/categories.component';
import { RemindersComponent } from './reminders/reminders.component';
import { NotesComponent } from './notes/notes.component';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth/auth.guard';
import { UserprofileComponent } from './user/userprofile/userprofile.component';

//This is my case 
const routes: Routes = [
    {path: '',redirectTo:'/user/registration',pathMatch:'full'},
    {path: 'user',component:UserComponent,
    children:[
        { path:'registration',component:RegistrationComponent },
        { path:'login',component:LoginComponent }
    ]},
    {
        path: 'Dashboard',component: DashboardComponent,canActivate:[AuthGuard],
        children: [
            { path: 'Category',component: CategoriesComponent},
            { path: 'Reminders',component: RemindersComponent},
            { path: 'Notes',component: NotesComponent},
            { path: 'UserProfile',component: UserprofileComponent}
        ]
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }