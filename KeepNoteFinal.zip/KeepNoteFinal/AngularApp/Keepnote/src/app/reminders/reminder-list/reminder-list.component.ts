import { Component, OnInit } from '@angular/core';
import { ReminderService } from 'src/app/shared/reminder.service';
import { Reminder } from 'src/app/shared/reminder.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-reminder-list',
  templateUrl: './reminder-list.component.html',
  styleUrls: ['./reminder-list.component.css']
})
export class ReminderListComponent implements OnInit {

  constructor(private reminderService: ReminderService,private toast: ToastrService) { }

  ngOnInit() {
    this.reminderService.refreshList();
  }
  populateForm(reminder: Reminder)
  {
    this.reminderService.reminderFormData = Object.assign({},reminder);
    this.reminderService.buttonText = "Update";
    this.reminderService.isUpdate = true;
  }
  onDelete(reminderId: number)
  {
    if(confirm('You want to delete?'))
    {
      this.reminderService.deleteReminder(reminderId).subscribe(res=>{this.toast.warning('Reminder deleted successfully','Delete Reminder');
      this.reminderService.refreshList();
    });
  }
}
}
