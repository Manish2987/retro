import { Component, OnInit } from '@angular/core';
import { ReminderService } from 'src/app/shared/reminder.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {

  constructor(private _reminderService: ReminderService,private toast: ToastrService) { }
  
  ngOnInit() {
    this.resetForm();
  }

  resetForm(reminderForm? : NgForm)
  {
    if(reminderForm !=null)
      reminderForm.resetForm();
    this._reminderService.reminderFormData = {
      Id: null,
    Name: '',
    Description: '', 
    Type: '',
    CreatedBy: '',
    CreationDate: null
    }
    this._reminderService.buttonText = "Create";
    this._reminderService.isUpdate = false;
  }

  onSubmit(reminderForm : NgForm)
  {
    debugger;
    if(reminderForm.value.Id == null)
      this.saveReminder(reminderForm);
    else
      this.updateReminder(reminderForm);    
  }
  saveReminder(reminderForm : NgForm)
  { 
    debugger;
    reminderForm.value.Id = 0;
    this._reminderService.postReminder(reminderForm.value).subscribe(res => {
      this.toast.success("Reminder added successfully","Create Reminder");
      this.resetForm(reminderForm);
      this._reminderService.refreshList();
    },
    err =>{      
      console.log(err);
      this.toast.error("Reminder already exists.","Create Reminder");
    });
  }

  updateReminder(reminderForm : NgForm){
    this._reminderService.putReminder(reminderForm.value).subscribe(res => {
      this.toast.info('Reminder data is updated successfully','Update Reminder');
      this.resetForm(reminderForm);
      this._reminderService.refreshList();
    });
  }
}

