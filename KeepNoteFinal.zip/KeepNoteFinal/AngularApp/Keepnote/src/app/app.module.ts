import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppComponent } from './app.component';
import { CategoriesComponent } from './categories/categories.component';
import { CategoryComponent } from './categories/category/category.component';
import { CategoryListComponent } from './categories/category-list/category-list.component';
import { CategoryService } from './shared/category.service';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ToastrModule } from 'ngx-toastr';
import { ReminderComponent } from './reminders/reminder/reminder.component';
import { ReminderListComponent } from './reminders/reminder-list/reminder-list.component';
import { RemindersComponent } from './reminders/reminders.component';
import { ReminderService } from './shared/reminder.service';
import { NotesComponent } from './notes/notes.component';
import { NoteComponent } from './notes/note/note.component';
import { NoteListComponent } from './notes/note-list/note-list.component';
import { NoteService } from './shared/note.service';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { AppRoutingModule } from './app-routing.module';
import { UserService } from './shared/user.service';
import { LoginComponent } from './user/login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserprofileComponent } from './user/userprofile/userprofile.component';

@NgModule({
  declarations: [
    AppComponent,
    CategoriesComponent,
    CategoryComponent,
    CategoryListComponent,
    ReminderComponent,
    ReminderListComponent,
    RemindersComponent,
    NotesComponent,
    NoteComponent,
    NoteListComponent,
    UserComponent,
    RegistrationComponent,
    LoginComponent,
    DashboardComponent,
    UserprofileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()    
  ],
  providers: [CategoryService,ReminderService,NoteService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
