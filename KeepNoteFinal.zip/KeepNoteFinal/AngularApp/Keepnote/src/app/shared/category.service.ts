import { Injectable } from '@angular/core';
import { Category } from './category.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NoteService } from './note.service';



@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categoryFormData: Category;
  list: Category[];  
  
  buttonText: string;
  isUpdate: boolean = false;
  readonly rootURL = "http://localhost:22200/api";
  constructor(private http: HttpClient,private noteService: NoteService) { }

  putCategory(categoryFormData : Category)
  {   
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    }); 
    return this.http.put(this.rootURL + "/category/" + categoryFormData.Id,categoryFormData,{headers:tokenHeader});
  }

  postCategory(categoryFormData : Category)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    });
    return this.http.post(this.rootURL + "/category",categoryFormData,{headers:tokenHeader});
  }

  refreshList()
  {    
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token'),
      'Cache-Control':'no-cache',
      'Pragma': 'no-cache'
    });
    this.list = null;
    this.http.get(this.rootURL + "/category/users",{headers:tokenHeader})
    .subscribe(res=> 
      {
        debugger;
        console.log(res);        
        this.list = res as Category[]
      });    
    this.buttonText="Create";
    this.isUpdate = false;
  }

  getCategoryById(categoryId: number)
  {    
    this.http.get(this.rootURL + "/category/" + categoryId,{
      headers: 
      {
        'Cache-Control':'no-cache',
        'Pragma': 'no-cache'
      }
    })
    .subscribe(res=> this.categoryFormData = res as Category);;
  }

  deleteCategory(categoryId: number)
  {
    return this.http.delete(this.rootURL + "/category/" + categoryId);
  }
}
