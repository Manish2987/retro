import { Injectable } from '@angular/core';
import { Authentication } from './authentication.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  authenticationFormData: Authentication;  
  constructor(private http: HttpClient) { }
  readonly rootURL = "http://localhost:22100/api";

  postUserAuthenticationDetails(authenticationData : Authentication)
  {
    return this.http.post(this.rootURL + "/auth/register",authenticationData);
  }

  postVerifyUserAuthenticationDetails(authenticationData : Authentication)
  {
    return this.http.post(this.rootURL + "/auth/login",authenticationData);
  }
}

