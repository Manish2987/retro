import { Injectable } from '@angular/core';
import { Note } from './note.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NoteService {
  noteFormData: Note;
  list: Note[];  
  buttonText: string;   
  isUpdate: boolean = false;
  readonly rootURL = "http://localhost:22400/api";
  constructor(private http: HttpClient) { }

  putNotes(noteFormData : Note)
  {   
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    }); 
    return this.http.put(this.rootURL + "/notes/" + noteFormData.Id,noteFormData,{headers:tokenHeader});
  }

  postNotes(noteFormData : Note)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    }); 
     return this.http.post(this.rootURL + "/notes",noteFormData,{headers:tokenHeader});
  }

  refreshList()
  {  
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token'),
      'Cache-Control':'no-cache',
      'Pragma': 'no-cache'
    }); 
    this.http.get(this.rootURL + "/notes",{headers:tokenHeader})
    .subscribe(
      res=>       
      this.list = res as Note[],
      err =>{   
        debugger;   
        console.log(err);
      });  
    this.buttonText="Create";
    this.isUpdate = false;
  }

  deleteNotes(noteId: number,createdBy: string)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    }); 
     return this.http.delete(this.rootURL + "/notes/" + noteId,{headers:tokenHeader});
  }
}

