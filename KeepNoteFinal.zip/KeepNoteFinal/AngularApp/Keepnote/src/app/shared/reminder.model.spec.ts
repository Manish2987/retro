import { Reminder } from './reminder.model';

describe('Reminder', () => {
  it('should create an instance', () => {
    expect(new Reminder()).toBeTruthy();
  });
});
