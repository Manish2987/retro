export class Category {
    Id: number;
    Name: string;
    Description: string;
    CreatedBy: string;
    CreationDate: Date;
}
