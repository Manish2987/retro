import { Injectable } from '@angular/core';
import { User } from './user.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userFormData: User;  
  readonly rootURL = "http://localhost:22500/api";
  constructor(private http: HttpClient) { }

  postUserDetails(userFormData : User)
  {
    return this.http.post(this.rootURL + "/user",userFormData);
  }
  
  updateUserDetails(userFormData : User)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    });
    return this.http.put(this.rootURL + "/user",userFormData,{headers:tokenHeader});
  }

  getUserDetails()
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token'),
      'Cache-Control':'no-cache',
      'Pragma': 'no-cache'
    });
    return this.http.get(this.rootURL + "/user",{headers:tokenHeader});
  }
}
