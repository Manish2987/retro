import { Category } from './category.model';
import { Reminder } from './reminder.model';

export class Note {
    Id: number;
    Title:string;
    Content:string;
    CreationDate: Date
    Category: Category;
    Reminder: Reminder;
    CreatedBy: string;
}
