export class User {
    UserId:string;
    Name:string;    
    Contact:string;    
    AddedDate:Date;
}
