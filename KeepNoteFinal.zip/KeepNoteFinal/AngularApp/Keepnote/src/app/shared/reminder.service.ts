import { Injectable } from '@angular/core';
import { Reminder } from './reminder.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NoteService } from './note.service';

@Injectable({
  providedIn: 'root'
})
export class ReminderService {
  reminderFormData: Reminder;
  list: Reminder[];  
  buttonText: string;
  isUpdate: boolean = false;
  readonly rootURL = "http://localhost:22300/api";
  constructor(private http: HttpClient,private noteService: NoteService) { }

  putReminder(reminderFormData : Reminder)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    });
    return this.http.put(this.rootURL + "/reminder/" + reminderFormData.Id,reminderFormData,{headers:tokenHeader});
  }

  postReminder(reminderFormData : Reminder)
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token')
    });
    return this.http.post(this.rootURL + "/reminder",reminderFormData,{headers:tokenHeader});

  }

  refreshList()
  {
    var tokenHeader = new HttpHeaders({
      'Authorization':'Bearer '+localStorage.getItem('token'),
      'Cache-Control':'no-cache',
      'Pragma': 'no-cache'
    });
    this.http.get(this.rootURL + "/reminder/users",{headers:tokenHeader})
    .subscribe(res=> this.list = res as Reminder[]);
    this.buttonText="Create";
    this.isUpdate = false;
  }
  deleteReminder(reminderId: number)
  {
    return this.http.delete(this.rootURL + "/reminder/" + reminderId);
  }
}
