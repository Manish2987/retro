export class Reminder {
    Id: number;
    Name: string;
    Description: string;    
    Type: string;
    CreatedBy: string;
    CreationDate: Date;
}
