export class Authentication {
    UserId:string;
    Password:string;
}
