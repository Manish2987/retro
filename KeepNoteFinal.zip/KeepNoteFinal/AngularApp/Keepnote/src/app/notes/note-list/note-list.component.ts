import { Component, OnInit } from '@angular/core';
import { NoteService } from 'src/app/shared/note.service';
import { Note } from 'src/app/shared/note.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-note-list',
  templateUrl: './note-list.component.html',
  styleUrls: ['./note-list.component.css']
})
export class NoteListComponent implements OnInit {

  constructor(private _noteService: NoteService,private toast: ToastrService) { }  
  ngOnInit() {
    debugger;
    this._noteService.refreshList();    
  }
  populateForm(note: Note)
  {
    debugger;
    this._noteService.noteFormData = Object.assign({},note);
    this._noteService.buttonText = "Update";
    this._noteService.isUpdate = true;
  }
  onDelete(categoryId: number,createdBy: string = "Tharun")
  {
    if(confirm('You want to delete note?'))
    {
    this._noteService.deleteNotes(categoryId,createdBy).subscribe(res=>{
      this.toast.warning('Note deleted successfully','Delete Note');
      this._noteService.refreshList();
    });
    }
  }
}
