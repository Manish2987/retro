import { Component, OnInit } from '@angular/core';
import { NoteService } from 'src/app/shared/note.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { Category } from 'src/app/shared/category.model';
import { CategoryService } from 'src/app/shared/category.service';
import { ReminderService } from 'src/app/shared/reminder.service';
import { Reminder } from 'src/app/shared/reminder.model';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {
  constructor(private _noteService: NoteService,private toast: ToastrService,private _categoryService: CategoryService,private _reminderService: ReminderService) { }  
  categoryData: Category;
  ngOnInit() {
    this.resetForm();
    this.loadCategory();   
    this.loadReminder();    
  }

  resetForm(noteForm? : NgForm)
  {
    if(noteForm !=null)
    noteForm.resetForm();
    this._noteService.noteFormData = {
      Id:null,
      Title:'',
      Content: '',
      Category: {Id:0,Name:'',CreatedBy:'',CreationDate:null,Description:''},
      Reminder:{Id:0,Name:'',CreatedBy:'',CreationDate:null,Description:'',Type:''},
      CreatedBy:'',
      CreationDate: null
    }
    this._noteService.buttonText = "Create";
    this._noteService.isUpdate = false;
  }

  loadCategory()
  {
    this._categoryService.refreshList();
  }

  loadReminder()
  {
    this._reminderService.refreshList();
  }

  onSubmit(noteForm : NgForm)
  {    
    if(noteForm.value.Id == null)
      this.saveNotes(noteForm);
    else
      this.updateNotes(noteForm);    
  }
  saveNotes(noteForm : NgForm)
  {     
    noteForm.value.Id = 0;     
    noteForm.value.Category = this._categoryService.list.find(e => e.Id == noteForm.value.Category);
    noteForm.value.Reminder = this._reminderService.list.find(e => e.Id == noteForm.value.Reminder);
    this._noteService.postNotes(noteForm.value).subscribe(res => {
      this.toast.success("Note added successfully","Create Notes");
      this.resetForm(noteForm);
      this._noteService.refreshList();
    },
    err =>{      
      console.log(err);
      this.toast.error("Notes already exists.","Create Notes");
    });
  }

  updateNotes(noteForm : NgForm){
    debugger;   
    noteForm.value.Category = this._categoryService.list.find(e => e.Id == noteForm.value.Category);
    noteForm.value.Reminder = this._reminderService.list.find(e => e.Id == noteForm.value.Reminder);
    this._noteService.putNotes(noteForm.value).subscribe(res => {
      this.toast.info('Note data is updated successfully','Update Notes');
      this.resetForm(noteForm);
      this._noteService.refreshList();
    });
  }

  
}
