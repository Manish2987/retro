﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace UserService.Models
{
    public class UserDbContext:DbContext
    {
        //declare variable to connect to MongoDB database
        MongoClient _mongoClient;
        private readonly IMongoDatabase database;
        public UserDbContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database using connection string and database name from configuration
            string connectionString = Environment.GetEnvironmentVariable("mongo_authentication");
            //_mongoClient = new MongoClient(configuration.GetSection("MongoDB:ConnectionString").Value);
            if (connectionString == null)
            {
                connectionString = configuration.GetSection("MongoDB:ConnectionString").Value;
            }
            _mongoClient = new MongoClient(connectionString);
            database = _mongoClient.GetDatabase(configuration.GetSection("MongoDB:UserDatabase").Value);
        }

        //Define a MongoCollection to represent the Reminders collection of MongoDB
        public IMongoCollection<User> Users
        {
            get
            {
                return database.GetCollection<User>("User");
            }
        }
    }
}
