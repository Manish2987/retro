﻿using UserService.Exceptions;
using UserService.Models;
using UserService.Repository;

namespace UserService.Service
{
    public class UserService: IUserService
    {
        //define a private variable to represent repository
        private IUserRepository _userRepository;

        //Use constructor Injection to inject all required dependencies.
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        //This method should be used to delete an existing user.
        public bool DeleteUser(string userId)
        {
            User objUser = _userRepository.GetUserById(userId);
            if (objUser == null)
                throw new UserNotFoundException("This user id does not exist");
            bool returnValue = _userRepository.DeleteUser(userId);

            return returnValue;

        }
        //This method should be used to delete an existing user
        public User GetUserById(string userId)
        {
            User objUser = _userRepository.GetUserById(userId);
            if (objUser == null)
                throw new UserNotFoundException("This user id does not exist");
            return objUser;
        }
        //This method is used to register a new user
        public User RegisterUser(User user)
        {
            User objUser = _userRepository.GetUserById(user.UserId);
            if (objUser == null)
                return _userRepository.RegisterUser(user);
            else
                throw new UserNotCreatedException("This user id already exists");
        }
        //This methos is used to update an existing user
        public bool UpdateUser(string userId, User user)
        {
            bool returnValue = false;
            returnValue = _userRepository.UpdateUser(userId, user);
            if (!returnValue)
                throw new UserNotFoundException("This user id does not exist");
            return returnValue;
        }
    }
}
