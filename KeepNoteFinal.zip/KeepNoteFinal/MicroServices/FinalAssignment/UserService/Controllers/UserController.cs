﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UserService.Models;
using UserService.Service;

namespace UserService.Controllers
{
    [ApiController]
    [Route("/api/user")]    
    public class UserController : Controller
    {
        /* Constructor Injection */
        private IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        /* Create user -- 
        * Return
            * 1. 201(CREATED) - If the user created successfully. 
            * 2. 409(CONFLICT) - If the userId conflicts with any existing user
        */
        [HttpPost]
        [Route("/api/user")]
        public ActionResult Post(User user)
        {
            try
            {                
                User objReturn = _userService.RegisterUser(user);
                return Created(Request.Path, objReturn);
            }
            catch (Exception ex)
            {
                return Conflict(ex.Message);
            }

        }



        /*
         * Update User
         * Return 
            * 1. 200(OK) - If the user updated successfully.
            * 2. 404(NOT FOUND) - If the user with specified userId is not found.         
         */
        [HttpPut]
        [Route("/api/user")]
        [Authorize]
        public ActionResult Put(User user)
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                user.UserId = userId;
                bool returnValue = _userService.UpdateUser(userId, user);                
                if (returnValue)
                    return Ok(user);
                else
                    return NotFound(user);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /*
         * Delete User
         * Return 
            * 1. 200(OK) - If the user deleted successfully from database. 
            * 2. 404(NOT FOUND) - If the user with specified userId is not found.         
         */
        [HttpDelete]
        [Route("/api/user")]
        [Authorize]
        public ActionResult Delete()
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                bool returnValue = _userService.DeleteUser(userId);                
                if (returnValue)
                    return Ok(true);
                else
                    return NotFound(false);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /*
         * Get User based on User id
         * Return 
            * 1. 200(OK) - If the user found successfully. 
            * 2. 404(NOT FOUND) - If the user with specified userId is not found.          
         */
        [HttpGet]
        [Route("/api/user")]        
        public ActionResult Get()
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                User user = _userService.GetUserById(userId);
                return Ok(user);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
