﻿using MongoDB.Driver;
using System;
using System.Linq;
using UserService.Models;

namespace UserService.Repository
{
    public class UserRepository: IUserRepository
    {
        //define a private variable to represent UserContext
        private UserDbContext context;
        public UserRepository(UserDbContext _context)
        {
            context = _context;
        }

        //This method should be used to delete an existing user.
        public bool DeleteUser(string userId)
        {
            bool returnValue = false;
            try
            {
                DeleteResult actionResult = context.Users.DeleteOne(eachUser => eachUser.UserId == userId);
                if (actionResult != null)
                {
                    returnValue = actionResult.DeletedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }

        //This method should be used to delete an existing user
        public User GetUserById(string userId)
        {
            User objUser = new User();
            try
            {
                objUser = context.Users.Find<User>(eachUser => eachUser.UserId == userId).FirstOrDefault();

            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
            return objUser;
        }

        //This method is used to register a new user
        public User RegisterUser(User user)
        {
            try
            {
                context.Users.InsertOne(user);
            }
            catch
            {
                throw new NotImplementedException();
            }
            return user;
        }

        //This methos is used to update an existing user
        public bool UpdateUser(string userId, User user)
        {
            bool returnValue = false;
            try
            {
                ReplaceOneResult objUser = context.Users.ReplaceOne(eachCat => eachCat.UserId == userId, user);
                if (objUser != null)
                {
                    returnValue = objUser.ModifiedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }
    }
}
