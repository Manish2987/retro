﻿using Microsoft.EntityFrameworkCore;
using System;

namespace AuthenticationService.Models
{
    public class AuthDbContext: DbContext
    {
        public AuthDbContext() { }
        public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options)
        {
            //make sure that database is auto generated using EF Core Code first
            try
            {
                Database.EnsureCreated();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        //Define a Dbset for User in the database
        public DbSet<Authentication> Users { get; set; }
    }
}
