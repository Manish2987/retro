﻿using AuthenticationService.Models;
using System;
using System.Linq;

namespace AuthenticationService.Repository
{
    public class AuthRepository: IAuthRepository
    {
        //Define a private variable to represent AuthDbContext
        private readonly AuthDbContext _context;
        public AuthRepository(AuthDbContext dbContext)
        {
            _context = dbContext;
        }

        //This methos should be used to Create a new User
        public bool CreateUser(Authentication user)
        {
            bool returnValue = false;
            try
            {
                _context.Users.Add(user);
                returnValue = _context.SaveChanges() >= 0 ? true : false;
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }

        //This methos should be used to check the existence of user
        public bool IsUserExists(string userId)
        {
            bool isExists = false;

            try
            {
                var objUser = _context.Users.FirstOrDefault(eachUser => eachUser.UserId == userId);
                if (objUser != null)
                    isExists = true;
                else
                    isExists = false;
            }
            catch
            {
                throw new NotImplementedException();
            }
            return isExists;
        }

        //This methos should be used to Login a user
        public bool LoginUser(Authentication user)
        {
            bool isValid = false;

            try
            {
                var objUser = _context.Users.FirstOrDefault(eachUser => eachUser.UserId == user.UserId && eachUser.Password == user.Password);
                if (objUser != null)
                    isValid = true;
                else
                    isValid = false;
            }
            catch
            {
                throw new NotImplementedException();
            }
            return isValid;
        }
    }
}
