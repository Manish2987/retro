﻿using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Repository;

namespace AuthenticationService.Service
{
    public class AuthService:IAuthService
    {
        //define a private variable to represent repository
        private IAuthRepository _authRepository;

        //Use constructor Injection to inject all required dependencies.
        public AuthService(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }

        //This methos should be used to register a new user
        public bool RegisterUser(Authentication user)
        {
            bool objUser = _authRepository.IsUserExists(user.UserId);
            if (objUser)
            {
                throw new UserAlreadyExistsException($"This userId {user.UserId} already in use");
            }
            return _authRepository.CreateUser(user);
        }

        //This method should be used to login for existing user
        public bool LoginUser(Authentication user)
        {
            bool isExist = _authRepository.LoginUser(user);
            return isExist;
        }
    }
}
