﻿using AuthenticationService.Models;

namespace AuthenticationService.Service
{
    public interface IAuthService
    {
        bool LoginUser(Authentication user);
        bool RegisterUser(Authentication user);
    }
}
