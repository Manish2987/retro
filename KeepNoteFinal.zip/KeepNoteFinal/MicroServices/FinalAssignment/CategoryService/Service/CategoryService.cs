﻿using CategoryService.Exceptions;
using CategoryService.Models;
using CategoryService.Repository;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;

namespace CategoryService.Service
{
    public class CategoryService : ICategoryService
    {
        //define a private variable to represent repository
        private ICategoryRepository repository;
        public CategoryService(ICategoryRepository _repository)
        {
            repository = _repository;
        }

        //This method should be used to save a new category.
        public Category CreateCategory(Category category)
        {
            try
            {
                return repository.CreateCategory(category);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //This method should be used to delete an existing category.
        public bool DeleteCategory(int categoryId)
        {
            bool returnValue = repository.DeleteCategory(categoryId);

            if (!returnValue)
            {
                throw new CategoryNotFoundException("This category id not found");
            }
            else
            {
                return returnValue;
            }
        }

        // This method should be used to get all category by userId
        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            return repository.GetAllCategoriesByUserId(userId);
        }

        //This method should be used to get a category by categoryId.
        public Category GetCategoryById(int categoryId)
        {
            Category objCategory = repository.GetCategoryById(categoryId);
            if (objCategory == null)
                throw new CategoryNotFoundException("This category id not found");
            return objCategory;
        }

        //This method should be used to update an existing category.
        public bool UpdateCategory(int categoryId, Category category)
        {
            Category objCategory = repository.GetCategoryById(categoryId);
            bool returnValue = false;
            returnValue = repository.UpdateCategory(categoryId, category);
            if (!returnValue)
                throw new CategoryNotFoundException("This category id not found");

            return returnValue;
        }
    }
}
