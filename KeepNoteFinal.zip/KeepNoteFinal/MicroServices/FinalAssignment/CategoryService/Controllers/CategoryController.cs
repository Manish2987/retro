﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CategoryService.Models;
using CategoryService.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CategoryService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : Controller
    {
        /* category service constructor injection */
        private ICategoryService _categoryService;
        public CategoryController(ICategoryService _service)
        {
            _categoryService = _service;
        }

        /*
	    * Create Category
	    Return	 
	     * 1. 201(CREATED - In case of successful creation of the category
	     * 2. 409(CONFLICT) - In case of duplicate categoryId
	    */
        [HttpPost]
        [Route("/api/category")]
        [Authorize]
        public ActionResult Post(Category category)
        {
            string userId = User.Claims.First(x => x.Type == "UserID").Value;
            try
            {                
                category.CreatedBy = userId;
                Category objCategory = _categoryService.CreateCategory(category);
                return Created(Request.Path, objCategory);
            }
            catch(Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /* Delete category
         * Return
            * 1. 200(OK) - If the category deleted successfully from database. 
            * 2. 404(NOT FOUND) - If the category with specified categoryId is not found.          
         */
        [HttpDelete]
        [Route("/api/category/{categoryId}")]
        public ActionResult Delete(int categoryId)
        {
            try
            {
                bool objCategory = _categoryService.DeleteCategory(categoryId);                
                if (objCategory)
                    return Ok(true);
                else
                    return NotFound(false);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /* Update category
         * Return
            * 1. 200(OK) - If the category updated successfully.
            * 2. 404(NOT FOUND) - If the category with specified categoryId is not found. 
         */
        [HttpPut]
        [Route("/api/category/{categoryId}")]
        [Authorize]
        public ActionResult Put(int categoryId, Category category)
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                category.CreatedBy = userId;
                bool objCategory = _categoryService.UpdateCategory(categoryId, category);                
                if (objCategory)
                    return Ok(true);
                else
                    return NotFound(false);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /*
         * Get Category by users
         * Return: 
           * 1. 200(OK) - If the category found successfully.          
         */
        [HttpGet]        
        [Route("/api/category/users")]
        [Authorize]
        public ActionResult Get()
        {            
            string userId = User.Claims.First(x => x.Type == "UserID").Value;
            List<Category> categories = _categoryService.GetAllCategoriesByUserId(userId);
            return Ok(categories);
        }

       /*
        * Get category by category id
        * Return
            * 1. 200(OK) - If the category found successfully.      
        */
        [HttpGet]
        [Route("/api/category/{categoryId}")]
        public ActionResult Get(int categoryId)
        {
            try
            {                
                Category category = _categoryService.GetCategoryById(categoryId);
                return Ok(category);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
