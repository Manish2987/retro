﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace CategoryService.Models
{
    public class CategoryDbContext : DbContext
    {
        MongoClient _mongoClient;
        private readonly IMongoDatabase database;
        public CategoryDbContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database using connection string and database name from configuration
            string connectionString = Environment.GetEnvironmentVariable("mongo_authentication");
            //_mongoClient = new MongoClient(configuration.GetSection("MongoDB:ConnectionString").Value);
            if (connectionString == null)
            {
                connectionString = configuration.GetSection("MongoDB:ConnectionString").Value;                
            }
            _mongoClient = new MongoClient(connectionString);
            database = _mongoClient.GetDatabase(configuration.GetSection("MongoDB:CategoryDatabase").Value);

        }

        //Define a MongoCollection to represent the Categories collection of MongoDB
        public IMongoCollection<Category> Categories
        {
            get
            {

                return database.GetCollection<Category>("Category");

            }
        }
    }
}
