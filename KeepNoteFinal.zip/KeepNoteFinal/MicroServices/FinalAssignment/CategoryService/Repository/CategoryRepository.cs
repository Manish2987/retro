﻿using CategoryService.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CategoryService.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private CategoryDbContext context;
        public CategoryRepository(CategoryDbContext _context)
        {
            context = _context;
        }

        //This method should be used to save a new category.
        public Category CreateCategory(Category category)
        {
            try
            {
                //var isDuplicateCategory = context.Categories.AsQueryable()
                //    .OrderByDescending(eachCat => eachCat.Name.Equals(category.Name)).FirstOrDefault();
                var isDuplicateCategory = context.Categories.Find(eacCategory => eacCategory.Name.Equals(category.Name)).ToList();
                if (isDuplicateCategory.Count() > 0)
                    throw new Exception("Category Already Exists.");
                var seqNumber = context.Categories.AsQueryable().OrderByDescending(eachCat => eachCat.Id).FirstOrDefault();
                if (seqNumber == null)
                    category.Id = 1;
                else
                    category.Id = category.Id == 0 ? seqNumber.Id + 1 : category.Id;
                context.Categories.InsertOne(category);
                return category;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //This method should be used to delete an existing category.
        public bool DeleteCategory(int categoryId)
        {
            bool returnValue = false;
            try
            {
                DeleteResult actionResult = context.Categories.DeleteOne(eachCat => eachCat.Id == categoryId);
                if (actionResult != null)
                {
                    returnValue = actionResult.DeletedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }

        /// <summary>
        /// this method is used to get categories by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Category> GetAllCategoriesByUserId(string userId)
        {

            List<Category> objCategories = new List<Category>();
            try
            {
                objCategories = context.Categories.Find(eacCategory => eacCategory.CreatedBy.Equals(userId)).ToList();

            }
            catch
            {
                throw new NotImplementedException();
            }
            return objCategories;
        }

        /*
	     * This method should be used to get a category by categoryId.
	     */
        public Category GetCategoryById(int categoryId)
        {
            Category objCategory = new Category();
            try
            {
                objCategory = context.Categories.Find(eachCategory => eachCategory.Id.Equals(categoryId)).FirstOrDefault();

            }
            catch
            {
                throw new NotImplementedException();
            }
            return objCategory;

        }

        /*
	    * This method should be used to update a existing category.
	    */
        public bool UpdateCategory(int categoryId, Category category)
        {
            bool returnValue = false;
            try
            {
                ReplaceOneResult objCategory = context.Categories.ReplaceOne(eachCat => eachCat.Id == categoryId, category);
                if (objCategory != null)
                {
                    returnValue = objCategory.ModifiedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;

        }
    }
}
