﻿using ReminderService.Exceptions;
using ReminderService.Models;
using ReminderService.Repository;
using System;
using System.Collections.Generic;

namespace ReminderService.Service
{
    public class ReminderService:IReminderService
    {
        //define a private variable to represent repository

        //Use constructor Injection to inject all required dependencies.
        private IReminderRepository repository;
        public ReminderService(IReminderRepository reminderRepository)
        {
            repository = reminderRepository;
        }

        //This method should be used to save a new reminder.
        public Reminder CreateReminder(Reminder reminder)
        {
            try
            {
                Reminder objReminder = repository.GetReminderById(reminder.Id);
                if (objReminder == null)
                    return repository.CreateReminder(reminder);
                else
                    throw new ReminderNotCreatedException("This reminder already exists");
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //This method should be used to delete an existing reminder.
        public bool DeleteReminder(int reminderId)
        {
            bool returnValue = repository.DeleteReminder(reminderId);
            if (!returnValue)
            {
                throw new ReminderNotFoundException("This reminder id not found");
            }
            else
            {
                return returnValue;
            }
        }
        // This method should be used to get all reminders by userId
        public List<Reminder> GetAllRemindersByUserId(string userId)
        {
            return repository.GetAllRemindersByUserId(userId);
        }
        //This method should be used to get a reminder by reminderId.
        public Reminder GetReminderById(int reminderId)
        {
            Reminder objReminder = repository.GetReminderById(reminderId);
            if (objReminder == null)
                throw new ReminderNotFoundException("This reminder id not found");
            return objReminder;
        }
        //This method should be used to update an existing reminder.
        public bool UpdateReminder(int reminderId, Reminder reminder)
        {
            bool returnValue = false;
            returnValue = repository.UpdateReminder(reminderId, reminder);
            if (!returnValue)
                throw new ReminderNotFoundException("This reminder id not found");

            return returnValue;
        }
    }
}
