﻿using MongoDB.Driver;
using ReminderService.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ReminderService.Repository
{
    public class ReminderRepository : IReminderRepository
    {
        //define a private variable to represent ReminderContext
        private ReminderDbContext context;
        public ReminderRepository(ReminderDbContext _context)
        {
            context = _context;
        }
        //This method should be used to save a new reminder.
        public Reminder CreateReminder(Reminder reminder)
        {
            //reminder Id should be auto generated and must start from 201
            try
            {
                var isDuplicateReminder = context.Reminders.Find(eachReminder => eachReminder.Name.Equals(reminder.Name)).ToList();
                if (isDuplicateReminder.Count() > 0)
                    throw new Exception("Reminder Already Exists.");
                var obj = context.Reminders.AsQueryable().OrderByDescending(eachRemin => eachRemin.Id).FirstOrDefault();
                if (obj == null)
                    reminder.Id = 1;
                else
                    reminder.Id = reminder.Id == 0 ? obj.Id + 1 : reminder.Id;
                context.Reminders.InsertOne(reminder);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return reminder;

        }
        //This method should be used to delete an existing reminder.
        public bool DeleteReminder(int reminderId)
        {
            bool returnValue = false;
            try
            {
                DeleteResult actionResult = context.Reminders.DeleteOne(eachRemin => eachRemin.Id == reminderId);
                if (actionResult != null)
                {
                    returnValue = actionResult.DeletedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }
        //This method should be used to get all reminders by userId
        public List<Reminder> GetAllRemindersByUserId(string userId)
        {
            List<Reminder> objReminders = new List<Reminder>();
            try
            {
                objReminders = context.Reminders.Find(eachReminder => eachReminder.CreatedBy.Equals(userId)).ToList();

            }
            catch
            {
                throw new NotImplementedException();
            }
            return objReminders;

        }
        //This method should be used to get a reminder by reminderId
        public Reminder GetReminderById(int reminderId)
        {
            Reminder objReminder = new Reminder();
            try
            {
                objReminder = context.Reminders.Find<Reminder>(eachReminder => eachReminder.Id == reminderId).FirstOrDefault();

            }
            catch
            {
                throw new NotImplementedException();
            }
            return objReminder;
        }
        // This method should be used to update an existing reminder.
        public bool UpdateReminder(int reminderId, Reminder reminder)
        {
            bool returnValue = false;
            try
            {
                ReplaceOneResult objReminder = context.Reminders.ReplaceOne(eachCat => eachCat.Id == reminderId, reminder);
                if (objReminder != null)
                {
                    returnValue = objReminder.ModifiedCount > 0 ? true : false;
                }
            }
            catch
            {
                throw new NotImplementedException();
            }
            return returnValue;
        }
    }
}
