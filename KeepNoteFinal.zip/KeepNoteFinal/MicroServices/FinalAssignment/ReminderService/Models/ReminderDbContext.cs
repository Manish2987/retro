﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace ReminderService.Models
{
    public class ReminderDbContext : DbContext
    {
        //declare variables to connect to MongoDB database
        MongoClient _mongoClient;
        private readonly IMongoDatabase database;
        public ReminderDbContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database using connection string and database name from configuration
            string connectionString = Environment.GetEnvironmentVariable("mongo_authentication");
            _mongoClient = string.IsNullOrEmpty(connectionString) ? new MongoClient(configuration.GetSection("MongoDB:ConnectionString").Value) : new MongoClient(connectionString); ;            
            //_mongoClient = new MongoClient(connectionString);
            database = _mongoClient.GetDatabase(configuration.GetSection("MongoDB:ReminderDatabase").Value);
        }

        //Define a MongoCollection to represent the Reminders collection of MongoDB
        public IMongoCollection<Reminder> Reminders
        {
            get
            {
                return database.GetCollection<Reminder>("Reminder");
            }
        }
    }
}
