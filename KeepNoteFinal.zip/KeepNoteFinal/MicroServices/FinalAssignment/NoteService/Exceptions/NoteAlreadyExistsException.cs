﻿using System;

namespace NoteService.Exceptions
{
    public class NoteAlreadyExistsException : ApplicationException
    {
        public NoteAlreadyExistsException(string message) : base(message) { }
    }
}
