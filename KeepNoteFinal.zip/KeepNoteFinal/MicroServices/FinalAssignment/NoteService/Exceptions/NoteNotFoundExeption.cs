﻿using System;

namespace NoteService.Exceptions
{
    public class NoteNotFoundExeption : ApplicationException
    {
        public NoteNotFoundExeption() { }
        public NoteNotFoundExeption(string message) : base(message) { }
    }
}
