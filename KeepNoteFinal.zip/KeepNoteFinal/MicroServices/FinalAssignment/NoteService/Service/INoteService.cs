﻿using NoteService.Models;
using System.Collections.Generic;

namespace NoteService.Service
{
    public interface INoteService
    {
        bool CreateNote(Note note);
        bool DeleteNote(string userId, int noteId);        
        Note UpdateNote(int noteId, string userId, Note note);        
        List<Note> GetAllNotesByUserId(string userId);
    }
}
