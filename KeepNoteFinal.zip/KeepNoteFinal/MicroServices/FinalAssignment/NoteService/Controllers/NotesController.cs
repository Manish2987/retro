﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NoteService.Models;
using NoteService.Service;

namespace NoteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotesController : Controller
    {
        /*
        NoteService should  be injected through constructor injection. Please note that we should not create service
        object using the new keyword
        */
        private INoteService _noteService;
        public NotesController(INoteService _service)
        {
            _noteService = _service;
        }

        /*
	    * Define a handler method which will create a specific note by reading the
	    * Serialized object from request body and save the note details in the
	    * database.This handler method should return any one of the status messages
	    * basis on different situations: 
	    * 1. 201(CREATED) - If the note created successfully. 
	    
	    * This handler method should map to the URL "/api/note/{userId}" using HTTP POST method
	    */
        [HttpPost]
        [Route("/api/notes")]
        [Authorize]
        public ActionResult Post(Note note)
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                note.CreatedBy = userId;
                bool objReturn = _noteService.CreateNote(note);
                return Created(Request.Path, note);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        /*
         * Define a handler method which will delete a note from a database.
         * This handler method should return any one of the status messages basis 
         * on different situations: 
         * 1. 200(OK) - If the note deleted successfully from database. 
         * 2. 404(NOT FOUND) - If the note with specified noteId is not found.
         *
         * This handler method should map to the URL "/api/note/{userId}/{noteId}" using HTTP Delete
         */
        [HttpDelete]
        [Route("/api/notes/{noteId}")]
        [Authorize]
        public ActionResult Delete(int noteId)
        {
            try
            {                
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                bool returnValue = _noteService.DeleteNote(userId, noteId);                
                if (returnValue)
                    return Ok(true);
                else
                    return NotFound(false);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        /*
         * Define a handler method which will update a specific note by reading the
         * Serialized object from request body and save the updated note details in a
         * database. 
         * This handler method should return any one of the status messages
         * basis on different situations: 
         * 1. 200(OK) - If the note updated successfully.
         * 2. 404(NOT FOUND) - If the note with specified noteId is not found.
         * 
         * This handler method should map to the URL "/api/note/{userId}/{noteId}" using HTTP PUT method.
         */
        [HttpPut]
        [Route("/api/notes/{noteId}")]
        [Authorize]
        public ActionResult Put(int noteId, Note note)
        {
            try
            {
                string userId = User.Claims.First(x => x.Type == "UserID").Value;
                Note returnValue = _noteService.UpdateNote(noteId, userId, note);
                //return new HttpResponseMessage(HttpStatusCode.Created);
                if (returnValue != null)
                    return Ok(note);
                else
                    return NotFound(note);
            }
            //catch (NoteNotFoundException ex)
            //{
            //    return NotFound(ex.Message);
            //}
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
               
        /*
        * Define a handler method which will get us the all notes by a userId.
        * This handler method should return any one of the status messages basis on
        * different situations: 
        * 1. 200(OK) - If the note found successfully. 
        * 
        * This handler method should map to the URL "/api/note/{userId}" using HTTP GET method
        */
        [HttpGet]
        [Route("/api/notes")]
        [Authorize]
        public ActionResult Get()
        {            
            string userId = User.Claims.First(x => x.Type == "UserID").Value;
            List<Note> notes = _noteService.GetAllNotesByUserId(userId);
            return Ok(notes);
        }
    }
}
