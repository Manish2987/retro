﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace NoteService.Models
{
    public class NoteDbContext: DbContext
    {
        //declare variables to connect to MongoDB database
        MongoClient _mongoClient;
        private readonly IMongoDatabase database;
        public NoteDbContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database using connection string and database name from configuration
            string connectionString = Environment.GetEnvironmentVariable("mongo_authentication");
            //_mongoClient = new MongoClient(configuration.GetSection("MongoDB:ConnectionString").Value);
            if (connectionString == null)
            {
                connectionString = configuration.GetSection("MongoDB:ConnectionString").Value;
            }
            _mongoClient = new MongoClient(connectionString);
            database = _mongoClient.GetDatabase(configuration.GetSection("MongoDB:NoteDatabase").Value);
        }

        //Define a MongoCollection to represent the Reminders collection of MongoDB
        public IMongoCollection<NoteUser> Notes
        {
            get
            {
                return database.GetCollection<NoteUser>("NoteUser");
            }
        }
    }
}
